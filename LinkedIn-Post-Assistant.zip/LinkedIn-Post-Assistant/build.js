/**
 * LinkedIn Post Summarizer - Build Script
 * 
 * This script prepares the extension for distribution by:
 * 1. Creating a build directory
 * 2. Copying necessary files to the build directory
 * 3. Creating a ZIP file for Chrome Web Store submission
 * 
 * Run with: node build.js
 */

const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Configuration
const BUILD_DIR = path.join(__dirname, '../build');
const SOURCE_DIR = __dirname;
const OUTPUT_ZIP = path.join(__dirname, '../linkedin-post-summarizer.zip');

// Files and directories to include in the build
const FILES_TO_COPY = [
  'manifest.json',
  'popup.html',
  'README.md'
];

const DIRS_TO_COPY = [
  'js',
  'styles',
  'assets'
];

// Create build directory if it doesn't exist
if (!fs.existsSync(BUILD_DIR)) {
  fs.mkdirSync(BUILD_DIR, { recursive: true });
  console.log(`Created build directory: ${BUILD_DIR}`);
}

// Copy individual files
FILES_TO_COPY.forEach(file => {
  const sourcePath = path.join(SOURCE_DIR, file);
  const destPath = path.join(BUILD_DIR, file);
  
  try {
    fs.copyFileSync(sourcePath, destPath);
    console.log(`Copied: ${file}`);
  } catch (err) {
    console.error(`Error copying ${file}: ${err.message}`);
  }
});

// Copy directories recursively
function copyDir(src, dest) {
  // Create destination directory
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }
  
  // Get all files and directories in the source directory
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      // Recursively copy subdirectory
      copyDir(srcPath, destPath);
    } else {
      // Copy file
      fs.copyFileSync(srcPath, destPath);
      console.log(`Copied: ${path.relative(SOURCE_DIR, srcPath)}`);
    }
  }
}

// Copy directories
DIRS_TO_COPY.forEach(dir => {
  const sourcePath = path.join(SOURCE_DIR, dir);
  const destPath = path.join(BUILD_DIR, dir);
  
  if (fs.existsSync(sourcePath)) {
    copyDir(sourcePath, destPath);
    console.log(`Copied directory: ${dir}`);
  } else {
    console.warn(`Warning: Directory not found: ${dir}`);
  }
});

console.log('\nBuild completed successfully!');

// Create a ZIP file for Chrome Web Store submission
function createZipArchive() {
  console.log('\nCreating ZIP archive for Chrome Web Store submission...');
  
  const output = fs.createWriteStream(OUTPUT_ZIP);
  const archive = archiver('zip', {
    zlib: { level: 9 } // Maximum compression
  });
  
  output.on('close', () => {
    console.log(`ZIP archive created: ${OUTPUT_ZIP}`);
    console.log(`Total size: ${(archive.pointer() / (1024 * 1024)).toFixed(2)} MB`);
  });
  
  archive.on('error', (err) => {
    throw err;
  });
  
  archive.pipe(output);
  
  // Add build directory contents to the ZIP
  archive.directory(BUILD_DIR, false);
  
  archive.finalize();
}

// Uncomment the line below to also create a ZIP archive
// createZipArchive();

console.log('\nTo create a ZIP archive for Chrome Web Store submission, uncomment the createZipArchive() function call in this script.'); 